<?php
$loc = "";

function setLoc($loc1)
{
  global $loc;
  $loc = $loc1;
}
