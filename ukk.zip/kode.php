<?php
session_start();
include "./bootstrap.php";
include "./global.php";
setLoc("kode");
include "./navbar.php";
include "./koneksi.php";

// paksa login dulu sebelum bisa pesan
if (!isset($_SESSION['email'])) {
  $next = 'confirm.php?id=' . $hotel['id'];
  header('Location: login.php?next=' . urlencode($next));
  exit;
}

if (!isset($_POST['booking'])) {
  echo '<div class="container mt-4"><div class="alert alert-danger">Form tidak dikirim.</div></div>';
  exit;
}

$hotel_id = (int)$_POST['hotel_id'];
$nights = max(1, (int)$_POST['nights']);
$nama = $db->real_escape_string($_POST['nama_pemesan'] ?? '');
$phone = $db->real_escape_string($_POST['phone'] ?? '');
$payment = $db->real_escape_string($_POST['payment_method'] ?? '');

// gunakan session email kalau login (lebih aman)
if (isset($_SESSION['email'])) {
  $email = $db->real_escape_string($_SESSION['email']);
} else {
  // fallback: ambil dari form (tapi idealnya user wajib login sebelum booking)
  $email = $db->real_escape_string($_POST['email_pemesan'] ?? '');
}

/* ambil data hotel */
$hres = $db->query("SELECT * FROM hotel WHERE id=$hotel_id LIMIT 1");
if (!$hres || !$hres->num_rows) {
  echo '<div class="container mt-4"><div class="alert alert-danger">Hotel tidak ditemukan.</div></div>';
  exit;
}
$hotel = $hres->fetch_assoc();

$total = (int)$hotel['harga'] * $nights;

/* CEK DOUBLE BOOKING (server-side) */
$chk = $db->query("SELECT id FROM orders WHERE hotel_id=$hotel_id AND user_email='$email' LIMIT 1");
if ($chk && $chk->num_rows) {
  echo '<div class="container mt-4"><div class="alert alert-warning">Gagal: Anda sudah melakukan booking untuk hotel ini sebelumnya.</div>';
  echo '<a class="btn btn-primary" href="history.php">Lihat Riwayat</a> <a class="btn btn-secondary" href="index.php">Kembali</a></div>';
  exit;
}

/* Simpan pesanan dengan code kosong dan status pending.
   Kode booking akan dibuat saat admin approve. */
$code_empty = ''; // empty string; db kolom code harus menerima string kosong
$db->query("INSERT INTO orders (code, hotel_id, user_email, nama_pemesan, phone, nights, total, payment_method, status) VALUES ('$code_empty', $hotel_id, '$email', '$nama', '$phone', $nights, $total, '$payment', 'pending')");
$order_id = $db->insert_id;

?>

<!doctype html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pesanan Dikirim</title></head>
<body>
  <div class="container mt-4">
    <h2>Pemesanan Terkirim</h2>
    <div class="card p-3">
      <p>Terima kasih, <?= htmlspecialchars($nama) ?>. Pesananmu untuk <strong><?= htmlspecialchars($hotel['name']) ?></strong> sebanyak <strong><?= $nights ?></strong> malam telah dikirim.</p>
      <p>Status sekarang: <strong>pending</strong> (menunggu persetujuan admin). Setelah admin menyetujui, kode booking akan muncul di halaman <a href="history.php">Riwayat Booking</a> kamu.</p>
      <p>Total: <strong>Rp <?= number_format((int)$total,0,',','.') ?></strong></p>
      <a class="btn btn-primary" href="history.php">Lihat Riwayat</a>
      <a class="btn btn-secondary" href="index.php">Kembali Cari Hotel</a>
    </div>
  </div>
</body>
</html>
