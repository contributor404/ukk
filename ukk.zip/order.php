<?php
session_start();
include "./koneksi.php";
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php"); exit;
}

if (isset($_POST['hotel_id'])) {
  $hid = (int)$_POST['hotel_id'];

  // ambil total kamar hotel
  $q = $db->query("SELECT total_kamar FROM hotel WHERE id=$hid");
  if(!$q || !$q->num_rows){
    echo "<div class='alert alert-danger'>Hotel tidak ditemukan.</div>";
    exit;
  }
  $h = $q->fetch_assoc();
  $totalKamar = (int)$h['total_kamar'];

  // cek kamar yang sudah terpakai
  $used = [];
  $r = $db->query("SELECT kamar_no FROM orders WHERE hotel_id=$hid AND status IN ('pending','approved','paid')");
  while($row = $r->fetch_assoc()){
    $used[] = (int)$row['kamar_no'];
  }

  // cari nomor kamar kosong
  $kamar_tersedia = null;
  for($i=1; $i<=$totalKamar; $i++){
    if(!in_array($i,$used)){
      $kamar_tersedia = $i;
      break;
    }
  }

  if($kamar_tersedia === null){
    echo "<div class='alert alert-danger'>Maaf, semua kamar hotel ini sudah penuh.</div>";
    exit;
  }

  // simpan pesanan
  $uid = (int)$_SESSION['user_id'];
  $db->query("INSERT INTO orders (user_id,hotel_id,kamar_no,status) VALUES ($uid,$hid,$kamar_tersedia,'pending')");
  header("Location: history.php");
  exit;
}
?>