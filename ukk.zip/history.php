<?php
session_start();
include "./bootstrap.php";
include "./global.php";
setLoc("history");
include "./navbar.php";
include "./koneksi.php";

// paksa login dulu sebelum bisa pesan
if (!isset($_SESSION['email'])) {
  $next = 'confirm.php?id=' . $hotel['id'];
  header('Location: login.php?next=' . urlencode($next));
  exit;
}

if (!isset($_SESSION['email'])) {
  echo '<div class="container mt-4"><div class="alert alert-danger">Silakan login dulu untuk melihat riwayat booking.</div></div>'; exit;
}

$email = $db->real_escape_string($_SESSION['email']);
$orders = $db->query("SELECT o.*, h.name AS hotel_name, h.slug AS hotel_slug, h.image AS hotel_image FROM orders o LEFT JOIN hotel h ON h.id=o.hotel_id WHERE o.user_email='$email' ORDER BY o.created_at DESC");
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Riwayat Booking</title>
  <style>
    /* style cetak sederhana supaya struk kelihatan rapi saat dicetak */
    .receipt {
      width: 320px;
      font-family: Arial, sans-serif;
      padding: 12px;
      border: 1px solid #ddd;
    }
    .receipt h3 { margin:0 0 6px 0; font-size:18px }
    .receipt p { margin:4px 0; font-size:14px }
    .small { font-size:12px; color:#666 }
    .btn { display:inline-block; padding:6px 10px; background:#2d6cdf; color:#fff; text-decoration:none; border-radius:4px }
    .btn-danger { background:#d9534f }
    .btn-secondary { background:#6c757d }
  </style>
  <script>
    // print receipt by taking innerHTML of hidden receipt div, open new window and print
    function printReceipt(id) {
      var rid = 'receipt-' + id;
      var content = document.getElementById(rid);
      if (!content) { alert('Struk tidak ditemukan'); return; }
      var w = window.open('', '_blank', 'width=400,height=700');
      var html = '<!doctype html><html><head><meta charset="utf-8"><title>Struk Booking</title>';
      html += '<style>body{font-family:Arial,Helvetica,sans-serif;padding:10px} .receipt{width:320px;border:0}</style>';
      html += '</head><body>' + content.innerHTML + '<script>window.onload = function(){ window.print(); /*window.close();*/ }<\/script></body></html>';
      w.document.open();
      w.document.write(html);
      w.document.close();
    }
  </script>
</head>
<body>
<div class="container mt-4">
  <h2>Riwayat Booking</h2>

  <?php if (!$orders || !$orders->num_rows): ?>
    <div class="alert alert-info">Belum ada riwayat booking.</div>
    <a href="index.php" class="btn">Cari Hotel</a>
  <?php else: ?>
    <table class="table table-bordered">
      <thead class="table-light">
        <tr>
          <th>Kode</th>
          <th>Hotel</th>
          <th>Jumlah Malam</th>
          <th>Total</th>
          <th>Status</th>
          <th>Tanggal</th>
          <th>Aksi</th> <!-- kolom aksi untuk tombol cetak -->
        </tr>
      </thead>
      <tbody>
        <?php while($o = $orders->fetch_assoc()): ?>
          <tr>
            <td>
              <?php
                if (!empty($o['code']) && $o['status'] !== 'pending') {
                  echo htmlspecialchars($o['code']);
                } else {
                  echo '<em>Menunggu persetujuan admin</em>';
                }
              ?>
            </td>
            <td>
              <a href="hotel.php?slug=<?= htmlspecialchars($o['hotel_slug']) ?>"><?= htmlspecialchars($o['hotel_name']) ?></a>
            </td>
            <td><?= (int)$o['nights'] ?></td>
            <td>Rp <?= number_format((int)$o['total'],0,',','.') ?></td>
            <td><?= htmlspecialchars($o['status']) ?></td>
            <td><?= htmlspecialchars($o['created_at']) ?></td>
            <td>
              <?php if (!empty($o['code']) && $o['status'] == 'paid'): ?>
                <!-- tombol cetak -->
                <button onclick="printReceipt(<?= (int)$o['id'] ?>)" class="btn">Cetak</button>
              <?php else: ?>
                <span class="small">-</span>
              <?php endif; ?>
            </td>
          </tr>

          <!-- hidden receipt div untuk setiap order (dipakai oleh printReceipt) -->
          <div id="receipt-<?= (int)$o['id'] ?>" style="display:none">
            <div class="receipt">
              <h3>LuxStay - Bukti Pemesanan</h3>
              <p class="small">Tanggal: <?= htmlspecialchars($o['created_at']) ?></p>
              <hr>
              <p><strong>Kode:</strong> <?= htmlspecialchars($o['code']) ?></p>
              <p><strong>Hotel:</strong> <?= htmlspecialchars($o['hotel_name']) ?></p>
              <p><strong>Nama:</strong> <?= htmlspecialchars($o['nama_pemesan']) ?></p>
              <p><strong>Jumlah Malam:</strong> <?= (int)$o['nights'] ?></p>
              <p><strong>Total:</strong> Rp <?= number_format((int)$o['total'],0,',','.') ?></p>
              <p><strong>Status:</strong> <?= htmlspecialchars($o['status']) ?></p>
              <hr>
              <p class="small">Terima kasih telah memesan. Simpan struk ini sebagai bukti.</p>
            </div>
          </div>

        <?php endwhile; ?>
      </tbody>
    </table>

    <a href="index.php" class="btn btn-secondary">Kembali</a>
  <?php endif; ?>
</div>
</body>
</html>
