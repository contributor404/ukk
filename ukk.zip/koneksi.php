<?php

$db = new mysqli("localhost", "root", "", "tiket-hotel");