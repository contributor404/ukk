<?php
session_start();
include "./bootstrap.php";
include "./global.php";
setLoc("admin");
include "./navbar.php";
include "./koneksi.php";

// cek login admin
if(!isset($_SESSION['email'])){
  header("Location: login.php"); exit;
}
$e = $db->real_escape_string($_SESSION['email']);
$r = $db->query("SELECT role,id FROM users WHERE email='$e' LIMIT 1");
if(!$r || !$r->num_rows){ header("Location: login.php"); exit; }
$role = $r->fetch_assoc()['role'];
if($role !== 'admin'){ header("Location: index.php"); exit; }

// approve
if(isset($_GET['approve'])){
  $oid = (int)$_GET['approve'];
  $res = $db->query("SELECT hotel_id,kamar_no FROM orders WHERE id=$oid");
  if($res && $res->num_rows){
    $o = $res->fetch_assoc();
    $hid = $o['hotel_id'];
    $kno = $o['kamar_no'];
    // cek bentrok kamar
    $cek = $db->query("SELECT id FROM orders WHERE hotel_id=$hid AND kamar_no=$kno AND status='approved'");
    if($cek->num_rows){
      echo "<div class='alert alert-danger'>Kamar no $kno sudah dipakai user lain, tidak bisa approve.</div>";
    }else{
      $newcode = 'BK'.date('YmdHis').rand(10,99);
      $db->query("UPDATE orders SET code='$newcode',status='approved',approved_at=NOW() WHERE id=$oid");
      header("Location: admin_orders.php"); exit;
    }
  }
}

// mark paid
if(isset($_GET['mark_paid'])){
  $oid = (int)$_GET['mark_paid'];
  $db->query("UPDATE orders SET status='paid',paid_at=NOW() WHERE id=$oid");
  header("Location: admin_orders.php"); exit;
}

// list pesanan
$orders = $db->query("SELECT o.*,u.username,h.name as hotel FROM orders o 
  JOIN users u ON o.user_id=u.id 
  JOIN hotel h ON o.hotel_id=h.id 
  ORDER BY o.id DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin - Pesanan</title>
</head>
<body class="container mt-4">
  <h2>Daftar Pesanan User</h2>
  <table class="table table-bordered">
    <thead><tr>
      <th>ID</th><th>User</th><th>Hotel</th><th>Kamar</th>
      <th>Status</th><th>Kode</th><th>Aksi</th>
    </tr></thead>
    <tbody>
      <?php while($row=$orders->fetch_assoc()){ ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['username']) ?></td>
        <td><?= htmlspecialchars($row['hotel']) ?></td>
        <td><?= $row['kamar_no'] ?></td>
        <td><?= $row['status'] ?></td>
        <td><?= $row['code'] ?></td>
        <td>
          <?php if($row['status']=='pending'){ ?>
            <a href="?approve=<?= $row['id'] ?>" class="btn btn-sm btn-success">Approve</a>
          <?php } elseif($row['status']=='approved'){ ?>
            <a href="?mark_paid=<?= $row['id'] ?>" class="btn btn-sm btn-primary">Mark Paid</a>
          <?php } ?>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</body>
</html>
